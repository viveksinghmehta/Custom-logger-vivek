//
//  CustomLogger.h
//  CustomLogger
//
//  Created by Vivek Mehta on 12/07/24.
//

#import <Foundation/Foundation.h>

//! Project version number for CustomLogger.
FOUNDATION_EXPORT double CustomLoggerVersionNumber;

//! Project version string for CustomLogger.
FOUNDATION_EXPORT const unsigned char CustomLoggerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CustomLogger/PublicHeader.h>


